# Derleiti Modern Theme

Ein modernes WordPress-Theme mit KI-Integration.

## Installation

1. Lade dieses Theme in das Verzeichnis /wp-content/themes/ hoch
2. Aktiviere das Theme über das WordPress-Admin-Panel
3. Installiere das Derleiti Plugin für erweiterte Funktionalität

## Systemanforderungen

- WordPress 6.2+
- PHP 8.1+
