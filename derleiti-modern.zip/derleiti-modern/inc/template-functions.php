<?php
/**
 * derleiti-modern/inc/template-functions.php
 * Auto-generierte Stub-Datei
 */

