<?php
/**
 * derleiti-modern/inc/template-tags.php
 * Auto-generierte Stub-Datei
 */

