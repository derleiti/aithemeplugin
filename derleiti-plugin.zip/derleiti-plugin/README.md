# Derleiti Plugin

Ein Plugin für erweiterte Funktionen des Derleiti Modern Themes mit KI-Integration.

## Installation

1. Lade dieses Plugin in das Verzeichnis /wp-content/plugins/ hoch
2. Aktiviere das Plugin über das WordPress-Admin-Panel

## Systemanforderungen

- WordPress 6.2+
- PHP 8.1+
- Derleiti Modern Theme (empfohlen)
