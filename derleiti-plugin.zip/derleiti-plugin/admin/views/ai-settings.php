<?php
/**
 * derleiti-plugin/admin/views/ai-settings.php
 * Auto-generierte Stub-Datei
 */

