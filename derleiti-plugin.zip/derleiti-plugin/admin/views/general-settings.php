<?php
/**
 * derleiti-plugin/admin/views/general-settings.php
 * Auto-generierte Stub-Datei
 */

