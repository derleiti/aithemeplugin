<?php
/**
 * derleiti-plugin/admin/views/main-settings.php
 * Auto-generierte Stub-Datei
 */

