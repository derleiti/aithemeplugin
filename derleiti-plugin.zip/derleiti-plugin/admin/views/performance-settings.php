<?php
/**
 * derleiti-plugin/admin/views/performance-settings.php
 * Auto-generierte Stub-Datei
 */

